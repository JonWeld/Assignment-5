import java.io.*;
import java.util.*;

public class PigGame {
    private static final int WINNING_SCORE = 100;
    private static final String FILENAME = "pig_game_data.txt";

    private static int[] scores;
    private static int currentPlayer;
    private static Random rand;

    public static void main(String[] args) {
        // Load game data from file
        loadGameData();

        // Initialize game variables
        scores = new int[2];
        currentPlayer = 0;
        rand = new Random();

        // Play the game
        while (true) {
            System.out.println("Player " + (currentPlayer + 1) + "'s turn:");
            int turnScore = takeTurn();
            scores[currentPlayer] += turnScore;
            System.out.println("Player " + (currentPlayer + 1) + " scored " + turnScore + " points this turn.");
            System.out.println("Player 1's score: " + scores[0]);
            System.out.println("Player 2's score: " + scores[1]);

            // Check if the game is over
            if (scores[currentPlayer] >= WINNING_SCORE) {
                System.out.println("Player " + (currentPlayer + 1) + " wins!");
                break;
            }

            // Switch to the other player's turn
            currentPlayer = (currentPlayer + 1) % 2;
        }

        // Save game data to file
        saveGameData();
    }

    private static int takeTurn() {
        int turnScore = 0;
        while (true) {
            int roll = rollDie();
            if (roll == 1) {
                System.out.println("You rolled a 1. Your turn is over.");
                return 0;
            } else {
                System.out.println("You rolled a " + roll + ".");
                turnScore += roll;
                System.out.println("Your turn score is " + turnScore + ". Roll again? (y/n)");
                Scanner scanner = new Scanner(System.in);
                String response = scanner.nextLine();
                if (!response.equalsIgnoreCase("y")) {
                    return turnScore;
                }
            }
        }
    }

    private static int rollDie() {
        return rand.nextInt(6) + 1;
    }

    private static void loadGameData() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(FILENAME));
            String line = reader.readLine();
            if (line != null) {
                String[] scoresStr = line.split(",");
                scores = new int[]{Integer.parseInt(scoresStr[0]), Integer.parseInt(scoresStr[1])};
                currentPlayer = Integer.parseInt(reader.readLine());
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Could not load game data from file.");
        }
    }

    private static void saveGameData() {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(FILENAME));
            writer.write(scores[0] + "," + scores[1]);
            writer.newLine();
            writer.write(String.valueOf(currentPlayer));
            writer.close();
        } catch (IOException e) {
            System.out.println("Could not save game data to file.");
        }
    }
}
